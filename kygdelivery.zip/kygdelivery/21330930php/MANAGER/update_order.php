<?php
include 'connect.php'; 
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'manager') {
    header("Location: ../signup/login.php");
    exit();
}

if (!isset($_GET['id'])) {
    echo "Order ID missing.";
    exit();
}

$order_id = $_GET['id'];

$sql = "SELECT orders.*, users.name AS customer_name, products.name AS product_name
        FROM orders
        JOIN users ON orders.user_id = users.id
        JOIN products ON orders.product_id = products.id
        WHERE orders.id = $order_id";
$res = mysqli_query($conn, $sql);
$order = mysqli_fetch_assoc($res);

if (!$order) {
    echo "Order not found.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_status = $_POST['status'];

    $update_sql = "UPDATE orders SET status = '$new_status' WHERE id = $order_id";
    if (mysqli_query($conn, $update_sql)) {
        header("Location: orders.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Order Status</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../style.css">
    <style>
        body {
            background-color: #FFA726;
        }
        .info-container {
            display: flex;
            justify-content: center;
            align-items: center;
            padding-top: 5px;
            padding-bottom: 40px;
        }

        .info-box {
            width: 400px;
            padding: 30px;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        .form-control, .form-select {
            height: 40px;
            font-size: 14px;
        }

        .btn-custom {
            font-size: 16px;
            font-weight: bold;
            padding: 10px 24px;
            border-radius: 30px;
            transition: all 0.3s ease-in-out;
            border: none;
        }

        .btn-custom:hover {
            transform: translateY(-2px);
        }

        .btn-update {
            background: linear-gradient(135deg, #28a745, #1e7e34);
            color: white;
            box-shadow: 0 4px 10px rgba(40, 167, 69, 0.4);
        }

        .btn-cancel {
            background: #6c757d;
            color: white;
        }
    </style>
</head>
<body>

<?php include 'navbarmanager.php'; ?>

<div class="info-container">
    <div class="info-box">
        <h4 class="text-center mb-3">Update Order Status</h4>

        <p><strong>Order ID:</strong> <?= $order['id'] ?></p>
        <p><strong>Customer:</strong> <?= $order['customer_name'] ?></p>
        <p><strong>Product:</strong> <?= $order['product_name'] ?></p>

        <form method="POST">
            <div class="form-group mb-3">
                <label for="status">Status</label>
                <select name="status" class="form-select" required>
                    <option <?= $order['status'] === 'Pending' ? 'selected' : '' ?>>Pending</option>
                    <option <?= $order['status'] === 'Accepted' ? 'selected' : '' ?>>Accepted</option>
                    <option <?= $order['status'] === 'Shipping' ? 'selected' : '' ?>>Shipping</option>
                    <option <?= $order['status'] === 'Delivered' ? 'selected' : '' ?>>Delivered</option>
                </select>
            </div>

            <button type="submit" class="btn btn-custom btn-update w-100 mb-2">Update</button>
            <a href="orders.php" class="btn btn-custom btn-cancel w-100">Cancel</a>
        </form>
    </div>
</div>

<?php include 'navfooter.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
