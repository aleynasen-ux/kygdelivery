<head>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js" crossorigin="anonymous"></script>
</head>

<footer class="footer mt-auto py-3 bg-dark text-white">
    <div class="container text-center">
        <div class="row">
            <div class="col-md-4">
                <h6>Useful Links</h6>
                <a href="manager.php">Manage products</a><br>
                <a href="orders.php">Orders</a><br>
                <a href="deliveries.php">Deliveries</a><br>
              
            </div>
            <div class="col-md-4">
                <h6>About</h6>
                <a href="#">About Us</a><br>
                <a href="#">Contact Us</a>
            </div>
            <div class="col-md-4">
               
                <div class="social-buttons mb-3">
    <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
    <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
    <a href="https://x.com" target="_blank"><i class="fab fa-x"></i></a>
</div>
            </div>
        </div>
      
    </div>
</footer>
