<?php
include 'connect.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'manager') {
    header("Location: ../signup/login.php");
    exit();
}

$manager_id = $_SESSION['user_id'];

$sql_restaurant = "SELECT id FROM restaurants WHERE user_id = $manager_id";
$res_restaurant = mysqli_query($conn, $sql_restaurant);
$row_restaurant = mysqli_fetch_assoc($res_restaurant);
$restaurant_id = $row_restaurant['id'];


$sql_orders = "SELECT orders.*, users.name AS customer_name, products.name AS product_name, products.price, orders.quantity, orders.total 
               FROM orders
               JOIN users ON orders.user_id = users.id
               JOIN products ON orders.product_id = products.id
               WHERE orders.restaurant_id = $restaurant_id
               ORDER BY orders.id DESC";
$res_orders = mysqli_query($conn, $sql_orders);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manager Orders</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../style.css">
</head>
<body>

<?php include 'navbarmanager.php'; ?>  

<div class="container mt-5">
    <h2 class="text-center mb-4">Incoming Orders</h2>

    <?php if (mysqli_num_rows($res_orders) === 0): ?>
        <div class="alert alert-warning">No orders yet</div>
    <?php else: ?>
        <table class="table table-bordered text-center align-middle">
            <thead class="table-dark">
                <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Qty</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Update</th>
                </tr>
            </thead>
            <tbody>
                <?php while($order = mysqli_fetch_assoc($res_orders)): ?>
                    <tr>
                        <td><?= $order['id'] ?></td>
                        <td><?= $order['customer_name'] ?></td>
                        <td><?= $order['product_name'] ?></td>
                        <td>₺<?= number_format($order['price'], 2) ?></td>
                        <td><?= $order['quantity'] ?></td>
                        <td>₺<?= number_format($order['total'], 2) ?></td>

                       <?php
                       $status = strtolower($order['status']);
                       $style = match ($status) {
                        'pending'   => 'background-color: #ffc107; color: black;',     
                        'accepted'  => 'background-color: #0d6efd; color: white;',     
                        'shipping'  => 'background-color: #0dcaf0; color: black;',     
                        'delivered' => 'background-color: #198754; color: white;',    
                        default     => 'background-color: #6c757d; color: white;',     
                        };
                        ?>
                        <td>
                            <span style="padding: 6px 12px; border-radius: 5px; font-size: 0.85rem; <?= $style ?>"><?= ucfirst($status) ?></span>
                        </td>
                        <td>
                            <a href="update_order.php?id=<?= $order['id'] ?>" class="btn btn-sm btn-primary">Update</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php include 'navfooter.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
